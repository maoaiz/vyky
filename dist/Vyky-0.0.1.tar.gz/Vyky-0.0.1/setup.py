from distutils.core import setup

setup(
    name='Vyky',
    version='0.0.1',
    author='Ramon M.',
    author_email='vyscond@gmail.com',
#    packages=[''], not need in here
    py_modules=['vyky'],
    scripts=['vyky.py'],
    url='https://github.com/vyscond/vyky',
    license='GPL-3.0',
    description='Vyscond\'s TSPLib Genetic Algorithm ',
    long_description=open('README.txt').read(),
)
